import { Injectable } from '@angular/core';
import { Product } from '../data/product';
import { Observable } from 'rxjs';
@Injectable({
  providedIn: 'root'
})
export class ProductServiceService {
  updateproduct:Product | undefined;
  private Product:Product[]=[];




  constructor(){
   this.Product=[
                      new Product(1,'Statuary White',"A sister stone to Carrara, Statuary marble features a uniform background and light gray tones with distinctive and more dramatic veining. Its semi translucent white background gives it a shiny, glossy feel, reflects light and provides a radiant finish that enhances any room.",75,"assets/Statuary White.png",1,1,"A sister stone to Carrara, Statuary marble features a uniform background and light gray tones with distinctive"),
                    new Product(2,'Emperador Brown',"Quarried from three regions of Spain, Emperador marble tile comes in different shades of brown, straying from the whites and grays associated with Calacatta and Carrara. It typically exhibits fine grains with irregular veins. Its darker color makes it an ideal choice .",84,"assets/Emperador Brown.png",2,2,"Quarried from three regions of Spain, Emperador marble tile comes in different shades of brown, straying from the whites "),
                    new Product(3,'Travertine beige',"Travertine marble is visibly porous, giving it a more natural and textured look and finish. However, when sanded down and sealed, this marble can be used for interior and exterior walls. Travertine ",90,"assets/Travertine beige.png",1,1,"Travertine marble is visibly porous, giving it a more natural and textured look and finish."),
                    new Product(4,'Calacatta',"One of the most well-known yet rare luxury stones, Calacatta marble is often confused with Carrara since both feature grey veining. However, unlike Carrara, Calacatta showcases bolder and more dramatic veining. Calacatta white marble or Calacatta gold marble are two of the most popular picks.",120,"assets/Calacatta.png",2,2,"One of the most well-known yet rare luxury stones, Calacatta marble is often confused with Carrara since both feature grey veining.")
                    ];
}
  
 Addproduct(product:Product):void{
  if(product.Id){
    const id=this.Product.findIndex(c => c.Id==product.Id);
    this.Product[id].Name=product.Name;
    this.Product[id].Description=product.Description;
    this.Product[id].Price=product.Price;
    this.Product[id].CategoryId=product.CategoryId;
    this.Product[id].ApplicationId=product.ApplicationId;
    this.Product[id].Image=product.Image;
    this.Product[id].Shortdescription=product.Shortdescription;
  }
  else{
    product.Id=this.Product.length+1;
    this.Product.push(product);
  }
  }
  getProduct():Product[] {
    return this.Product;
    
  }
  getproductId(id:number):Product|undefined{
    return this.Product.find(c=> c.Id===id);
    }
    deleteproduct(id:number):void{
      const num=this.Product.findIndex(c =>  c.Id===id );
      //console.log(num);
      this.Product.splice(num,1);
      //console.log(this.category);
    }
    productavilableforapplications(id:number|undefined):boolean{
      const temp=this.Product.find(c=>c.ApplicationId===id)
      if(temp!=undefined){
        return true;
      }
      return false;
    }
    productavilableforcategory(id:number|undefined):boolean{
      const temp=this.Product.find(c=>c.CategoryId===id)
      if(temp!=undefined){
        return true;
      }
      return false;
    }
  

 
  
}
