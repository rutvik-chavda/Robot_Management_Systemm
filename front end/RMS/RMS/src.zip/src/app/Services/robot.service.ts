import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class RobotService {

  //Isadmin: boolean = true;
  //Islogin:boolean=true;
  //username:string = '';

  baseApiUrl: string = "https://localhost:44372/";
  constructor(private http: HttpClient) { }
  /* adminLogin(b:boolean){
    this.Isadmin = b;
  }
  userlogin(b:boolean,name:string){
    this.username=name;
    this.Islogin=b;
  } */
  Login(Userdetails: any): Observable<any> 
  {
    return this.http.post<any>(this.baseApiUrl + 'api/Authentication/Login',Userdetails );
  }
  Register(Userdetails: any): Observable<any> 
  {
    return this.http.post<any>(this.baseApiUrl + 'api/Authentication/register-Admin',Userdetails );
  }
  GetRobot(): Observable<any>{
    return this.http.get<any>(this.baseApiUrl +'api/Robot/GetRobot');
  }
  GetRobotById(id: number): Observable<any>{
    return this.http.get<any>(this.baseApiUrl +'api/Robot/getRobotid?id='+id);
  }
  DeleteRobotByid(id: number): Observable<any>{
    return this.http.delete<any>(this.baseApiUrl +'api/Robot/DeleteRobot?id='+id);
  }
  AddRobot(product:any): Observable<any>{
    return this.http.post<any>(this.baseApiUrl +'api/Robot/AddRobot',product);
  }
  UpdateRobot(product:any): Observable<any>{
    return this.http.put<any>(this.baseApiUrl +'api/Robot/UpdateRobot',product);
  }
}
