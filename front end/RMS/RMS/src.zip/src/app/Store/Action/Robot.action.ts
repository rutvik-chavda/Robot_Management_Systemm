import { robot } from "src/app/data/robot";
export class AddRobot{
    static readonly type='[Robot] Add'; 
    constructor(public payLoad:robot) { }
}
export class GetRobot{
    static readonly type='[Robot] Get'; 
}

export class DeleteRobot{
    static readonly type='[Robot] Delete'; 
    constructor(public id:number) {}
}
export class UpdateRobot{
    static readonly type='[Robot] Update';
    constructor(public payLoad:robot ) { } 
}
export class SetSelectedRobot{
    static readonly type='[Robot] Set';
    constructor(public id:number){}
}