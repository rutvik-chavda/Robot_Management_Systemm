import { Injectable } from "@angular/core";
import { Action, Selector, State, StateContext } from "@ngxs/store";
import { robot } from "src/app/data/robot";
//import { state } from '@angular/animations';
import { GetRobot, DeleteRobot, SetSelectedRobot, AddRobot, UpdateRobot } from '../Action/Robot.action';
import { RobotService } from '../../Services/robot.service';
import {  tap } from "rxjs";
//import { NavigationStart } from '@angular/router';
import { Product } from '../../data/product';

export class RobotSateModel{
    robots ?:robot[];
    robotsLoaded?:boolean;
    selectedRobot:robot | undefined;
}

@State<RobotSateModel>({ 
    name:'Robots',
    defaults:{
        robots:[],
        robotsLoaded:false,
        selectedRobot:undefined

    }

})
@Injectable()
export class RobotState{
    
    constructor(private RobotService:RobotService) {
       
        
    }
    @Selector()
    static getRobotList(state:RobotSateModel){
        return state.robots;
    }
    @Selector()
    static getrobotsLoaded(state:RobotSateModel){
        return state.robotsLoaded;
    }
    @Action(GetRobot)
    getRobot({getState,setState}:StateContext<RobotSateModel>){
        console.log("state action"); 
     return   this.RobotService.GetRobot().pipe(tap (r=>{
            console.log(r);
            const state=getState();
            setState({
                ...state,
                robots:r,
                robotsLoaded:true
            })
        }))
    }
    //delete data to state 
    @Action(DeleteRobot)
    deleteRobot({getState,setState}:StateContext<RobotSateModel>,{id}:DeleteRobot){
        return this.RobotService.DeleteRobotByid(id).pipe(tap (r=>{
            console.log(r,"bare")
        if(r.status=="Success")
        {
            console.log("andar")
            const state=getState();
            const filterstate=state.robots?.filter(rob=>rob.id!==id);
            console.log(filterstate);
            setState({
                ...state,
                robots:filterstate,
                robotsLoaded:true
            })
            console.log(getState());
        }
    }))
    }
    @Selector( )
    static selectedRobot(state:RobotSateModel){
        return state.selectedRobot;
    }
    @Action(SetSelectedRobot)
    setSelectedRobot({getState,setState}:StateContext<RobotSateModel>,{id}:SetSelectedRobot){
        console.log(id,"new");
        const state=getState();
        const robList=state.robots?.filter(re=>1==1);
        const index=robList?.findIndex(re=>re.id===id);
        console.log(index,"index");
        console.log(robList,"robots");
        if(robList!=undefined&&index!=undefined)
        {
            //console.log("ji")
    if(robList.length>0&& index>0){
        console.log("indi");
        setState({
            ...state,
            selectedRobot:robList[index]
        });
        return
    }
    else
    {
        console.log("ji")
        return this.RobotService.GetRobotById(id).pipe(tap((res:any)=>{
            console.log(res,"index")
            const ronlist:[robot]=[res];
            console.log(ronlist,"lidt");
            console.log(ronlist[0],"nnkfn")

            setState({
                ...state,
                robots:ronlist,
                robotsLoaded:true,
                selectedRobot:ronlist[0]
            }) 
        }));
    }
    }
    return
    //console.log("ki")
        


    }
    @Action(AddRobot)
    addRobot({getState,patchState}:StateContext<RobotSateModel>,{payLoad}:AddRobot){
        console.log(payLoad,"addRobot ");
        return this.RobotService.AddRobot(payLoad).pipe(tap((res:robot)=>{
            const state=getState();
            if(state.robots!=undefined)
            patchState({
                robots:[...state.robots,res]
            })
        }));
    }
    @Action(UpdateRobot)
    updateRobot({getState,patchState}:StateContext<RobotSateModel>,{payLoad}:UpdateRobot){
        console.log(payLoad,"updateRobot");
        return this.RobotService.UpdateRobot(payLoad).pipe(tap((res:robot)=>{
            console.log(res,"hi");
            const state=getState();
            const robList=state.robots;
            const index=robList?.findIndex(rob=>rob.id==payLoad.id);
            if(robList!=undefined && index!=undefined)
            robList[index]=payLoad;
            if(state.robots!=undefined)
            patchState({
                robots:robList,
            })
        }))
    }
    
}