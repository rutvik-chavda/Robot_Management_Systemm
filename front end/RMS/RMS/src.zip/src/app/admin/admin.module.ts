
import { CommonModule } from '@angular/common';
import { RouterModule, Routes } from '@angular/router';
import { ReactiveFormsModule } from '@angular/forms';
import { DisplayRobotlistComponent } from './display-robotlist/display-robotlist.component';
import { CreateRobotComponent } from './create-robot/create-robot.component';
import { NgModule } from '@angular/core';
import { MatInputModule } from '@angular/material/input';
import { MatButtonModule } from '@angular/material/button';
import { MatTableModule } from '@angular/material/table';
import { MatPaginatorModule } from '@angular/material/paginator';
import { MatSortModule } from '@angular/material/sort';
import { HttpClientModule } from '@angular/common/http';
import { CommonModul } from '../common/common.module';

const routes: Routes = [
  {
    path: '',
    children: [
      {path:'createproduct/:id',component:CreateRobotComponent},
      { path: 'Robotlist', component: DisplayRobotlistComponent },
    ]
  }
];

@NgModule({
  declarations: [
    DisplayRobotlistComponent,
    CreateRobotComponent
  ],
  imports: [
    CommonModule,
    RouterModule,
    ReactiveFormsModule,
    HttpClientModule,
    MatInputModule,
    MatButtonModule,
    MatTableModule,
    MatPaginatorModule,
    MatSortModule,
    CommonModul,
    RouterModule.forChild(routes)
  ],
  exports:
  [
    DisplayRobotlistComponent]
})
export class AdminModule {
  constructor(){
    console.log("admin midules")
  }
 }
