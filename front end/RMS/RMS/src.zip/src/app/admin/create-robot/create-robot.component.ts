import { Component, OnDestroy, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { ProductServiceService } from 'src/app/Services/product-service.service';
import { Product } from 'src/app/data/product';
import { UserserviceService } from '../../Services/userservices.service';
import { robot } from 'src/app/data/robot';
import { Select, Store } from '@ngxs/store';
import { AddRobot, SetSelectedRobot, UpdateRobot } from 'src/app/Store/Action/Robot.action';
import { Observable, Subscription, Subscribable } from 'rxjs';
import { RobotState } from 'src/app/Store/State/Robot.state';

@Component({
  selector: 'app-create-product',
  templateUrl: './create-robot.component.html',
  styleUrls: ['./create-robot.component.css']
})
export class CreateRobotComponent implements OnInit, OnDestroy {
 
  public robotForm!: FormGroup;
  public robot! : robot ; // Initialize with a default robot object
  public id: number = 0;
  suscribe!: Subscription;
  @Select(RobotState.selectedRobot) selectedrobot$!: Observable<robot>;

  constructor(
    private formBuilder: FormBuilder,
    public router: Router,
    public route: ActivatedRoute,
    private store: Store 
  ) {
    this.route.paramMap.subscribe(params => {
      this.id = Number(params.get('id'));
      //console.log(this.id);
    });

    this.robotForm = this.formBuilder.group({
      robotName: ['', Validators.required],
      ownerName: ['', Validators.required],
      location: ['', Validators.required],
      firmwareVersion: ['', Validators.required]
    });

    if(this.id!=0){
    this.suscribe = this.selectedrobot$.subscribe(res => {
      //console.log(res, "bo");
      this.robot = res;
      //console.log(this.robot);
      this.robotForm.patchValue({
        robotName: res?.robotName || '',
        ownerName: res?.ownerName || '',
        location: res?.location || '',
        firmwareVersion: res?.firmwareVersion || ''
      });
    });

    this.store.dispatch(new SetSelectedRobot(this.id));
  }
  }

  ngOnDestroy(): void {
    this.suscribe.unsubscribe();
  }

  ngOnInit(): void {
    // Other initialization tasks can be performed here if needed.
  }

  async onSubmit() {
    const no = new robot(
      this.id,
      this.robotForm.controls['robotName'].value,
      this.robotForm.controls['ownerName'].value,
      this.robotForm.controls['location'].value,
      this.robotForm.controls['firmwareVersion'].value
    );
    if(this.id==0){
    
 const a=this.store.dispatch(new AddRobot(no));
        a.subscribe(res=>{
          //console.log(res,"a");
        this.router.navigate(['/admin/Robotlist']);

        });

        

    }
    else{ 
      const a=  this.store.dispatch(new UpdateRobot(no));
      a.subscribe(res=>{
     this.router.navigate(['/admin/Robotlist']);

      })
      

    }

  
  }
}
