import { Component, OnInit, OnDestroy } from '@angular/core';
import { Select, Store } from '@ngxs/store';
import { Observable, Subscription } from 'rxjs';
import { DeleteRobot, GetRobot } from 'src/app/Store/Action/Robot.action';
import { RobotState } from 'src/app/Store/State/Robot.state';
import { robot } from 'src/app/data/robot';
import { Router } from '@angular/router';
import { Product } from 'src/app/data/product';
import { MatTableDataSource } from '@angular/material/table';

@Component({
  selector: 'app-display-productlist',
  templateUrl: './display-robotlist.component.html',
  styleUrls: ['./display-robotlist.component.css']
})
export class DisplayRobotlistComponent implements OnInit, OnDestroy {
  productdata: robot[] = [];
  subscribable?: Subscription;
  datasource!:MatTableDataSource<robot>;

  @Select(RobotState.getRobotList) robotes$!: Observable<robot[]>;

  constructor(private store: Store, private router: Router) {
    if(this.robotes$!=undefined)
   this.robotes$.subscribe(r=>{
    this.datasource=new MatTableDataSource<robot>(r);
   
   }) 
  }

  ngOnInit(): void {
    this.getRobots();
    this.robotes$.subscribe(r => {
      console.log(r, 'dnjn');
    });
  }

  
  getRobots(): void {
    this.store.dispatch(new GetRobot());
  }

  ngOnDestroy(): void {
    this.subscribable?.unsubscribe();
  }
}
