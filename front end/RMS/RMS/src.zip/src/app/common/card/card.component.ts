import { Component, Input, OnInit } from '@angular/core';
import { robot } from 'src/app/data/robot';

@Component({
  selector: 'app-card',
  templateUrl: './card.component.html',
  styleUrls: ['./card.component.css']
})
export class CardComponent implements OnInit {
  @Input() Product: robot[] | null = [];

  constructor() {
    this.waitableMethod()
      .then(result => {
        // Here, you can work with the 'result' array
        console.log(result,"done");
      })
      .catch(error => {
        // Handle any potential errors
        console.error(error);
      });
  }

  ngOnInit(): void {
    
  }

  waitableMethod(): Promise<robot[]> {
    return new Promise<robot[]>((resolve, reject) => {
      if (this.Product && this.Product.length > 0) {
        resolve(this.Product);
      } else {
        setTimeout(() => {
           reject(this.Product);
        }, 2000); // 2 seconds delay
      }
    });
  }
}
