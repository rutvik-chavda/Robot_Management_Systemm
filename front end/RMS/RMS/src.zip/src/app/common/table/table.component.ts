import { Component, ViewChild, ElementRef, Input, AfterViewInit } from '@angular/core';
import { MatPaginator } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';
import { MatTableDataSource } from '@angular/material/table';
import { RouterEvent } from '@angular/router';
import { robot } from 'src/app/data/robot';
import { Store } from '@ngxs/store';
import { DeleteRobot } from 'src/app/Store/Action/Robot.action';

@Component({
  selector: 'app-table',
  templateUrl: './table.component.html',
  styleUrls: ['./table.component.css']
})
export class TableComponent implements AfterViewInit {
  @Input() Product!:MatTableDataSource<robot>;

  displayedColumns: string[] = ['id', 'robotName', 'ownerName', 'location', 'firmwareVersion', 'actions'];
  dataSource ?: MatTableDataSource<robot>;

  @ViewChild(MatPaginator) paginator!: MatPaginator;
  @ViewChild(MatSort) sort!: MatSort;
  @ViewChild('filterInput') filterInput!: ElementRef<HTMLInputElement>;

  constructor(private store:Store) {
   /*  var robots:robot[] = [];
    if(this.Product!=null)
    robots=this.Product;
    if(robots!=undefined)
    this.dataSource = new MatTableDataSource<robot>(robots);
    console.log("undefined robots") */
  }

  ngAfterViewInit() {
    console.log("Inside");
    this.Product.paginator = this.paginator;
    this.Product.sort = this.sort;
  }

  ondeleteRobot(id:number){
    if(confirm("Are you sure you want to delete?")){
      //console.log(id);
      this.store.dispatch(new DeleteRobot(id));
    }
  }
  applyFilter() {
    const filterValue = this.filterInput.nativeElement.value.trim().toLowerCase();

      this.Product.filter = filterValue;
    }
    
  }

