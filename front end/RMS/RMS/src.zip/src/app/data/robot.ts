export class robot {
    id?:number ;
    robotName?:string;
    ownerName?:string;
    location?:string;
    //lastActive?:Date;
    firmwareVersion?:number;

    constructor(id:number, robotName:string, ownerName:string, location:string, firmwareVersion:number) {
      this.id = id;
      this.robotName = robotName;
      this.ownerName = ownerName;
      this.location = location;
      //this.lastActive = lastActive
      this.firmwareVersion= firmwareVersion;

    }

   
}
