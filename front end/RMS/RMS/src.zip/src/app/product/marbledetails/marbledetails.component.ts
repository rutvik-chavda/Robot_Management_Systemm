import { Component, OnDestroy, OnInit } from '@angular/core';
import { ProductServiceService } from 'src/app/Services/product-service.service';
import { Router } from '@angular/router';
import { Product } from 'src/app/data/product';
import { UserserviceService } from '../../Services/userservices.service';
import { Store,Select } from '@ngxs/store';
import { GetRobot } from 'src/app/Store/Action/Robot.action';
import { Observable, Subscribable, Subscription } from 'rxjs';
import { robot } from 'src/app/data/robot';
import { RobotState } from 'src/app/Store/State/Robot.state';





@Component({
  selector: 'app-marbledetails',
  templateUrl: './marbledetails.component.html',
  styleUrls: ['./marbledetails.component.css']
})
export class MarbledetailsComponent implements OnInit,OnDestroy {
  
  productdata:Product[]=[];
  Subscribable?:Subscription;
  @Select(RobotState.getRobotList) robotes$?:Observable<robot[]>;
  @Select(RobotState.getrobotsLoaded) robotesLoades?:Observable<boolean>;


  constructor(private store:Store,public Productdataservice:ProductServiceService,private Router:Router,public UserserviceService:UserserviceService){
    
  }
  
  ngOnInit(): void {
   this.getrobots();
    if(this.robotes$!=undefined)
   this.robotes$.subscribe(r=>{
    console.log(r,"dnjn");
   }) 
  }

  
  getrobots(){
   
    this.Subscribable= this.robotesLoades?.subscribe(robotesLoade=>{
      if(!robotesLoade){
          this.store.dispatch(new GetRobot());
      }
    })
  
  }
  ngOnDestroy(): void {
    this.Subscribable?.unsubscribe();
  }
}
