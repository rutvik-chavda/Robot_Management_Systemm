import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MarbledetailsComponent } from './marbledetails/marbledetails.component';
import { DetailsComponent } from './details/details.component';
import { RouterModule, Routes } from '@angular/router';
import { FormsModule } from '@angular/forms';
import { CommonModul } from '../common/common.module';


const routes: Routes = [
  {
    path: '',
    children: [
      {path:'details/:id',component:DetailsComponent},
    ]
  }
];
@NgModule({
  declarations: [
    MarbledetailsComponent,
    DetailsComponent
  ],
  imports: [
    CommonModule,
    RouterModule,
    FormsModule,
    RouterModule.forChild(routes),
    CommonModul

  ],
  exports:[
    MarbledetailsComponent]
})
export class ProductModule { }
